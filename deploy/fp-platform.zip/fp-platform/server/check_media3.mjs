import mysql from 'mysql2/promise'
const pool = mysql.createPool({
  host: process.env.DB_HOST, port: 3306, database: process.env.DB_NAME,
  user: process.env.DB_USER, password: process.env.DB_PASSWORD,
  charset: 'utf8mb4', dateStrings: true
})
async function q(sql, p=[]) { const [r]=await pool.execute(sql,p); return r }
// 精度表里 fp>0 的标签数
const pf = await q('SELECT COUNT(*) n FROM real_data_tag_precision WHERE fp>0')
console.log('precision tags with fp>0:', pf[0].n)
// 这些标签里，real_data_samples 有对应 is_fp=1 的比例（取前几个）
const tags = await q('SELECT tag_id, SUM(fp) fp FROM real_data_tag_precision WHERE fp>0 GROUP BY tag_id ORDER BY fp DESC LIMIT 5')
for(const t of tags){
  const s = await q('SELECT COUNT(*) n FROM real_data_samples WHERE tag_id=? AND is_fp=1', [t.tag_id])
  console.log('tag', t.tag_id, 'fp=', t.fp, 'real_data_samples is_fp=1=', s[0].n)
}
// precision_samples 是否真的完全空
const ps = await q('SELECT COUNT(*) n FROM real_data_tag_precision_samples')
console.log('precision_samples total rows:', ps[0].n)
await pool.end()
