import mysql from 'mysql2/promise'
const pool = mysql.createPool({ host:process.env.DB_HOST, port:3306, database:process.env.DB_NAME, user:process.env.DB_USER, password:process.env.DB_PASSWORD, charset:'utf8mb4', dateStrings:true })
// 精确 JOIN（去参后相等）命中
const exact = await pool.query(`SELECT COUNT(*) c FROM real_data_samples s JOIN ai_evaluate_detail_url_idx d ON d.element_value_norm = SUBSTRING_INDEX(s.media_url,'?',1) WHERE s.media_url<>''`)
console.log('精确去参命中:', JSON.stringify(exact[0]))
// 反向：ai_idx 的 norm 是否被 samples media_url 包含（samples 带参数）
const like = await pool.query(`SELECT COUNT(*) c FROM real_data_samples s WHERE s.media_url<>'' AND EXISTS (SELECT 1 FROM ai_evaluate_detail_url_idx d WHERE s.media_url LIKE CONCAT('%',d.element_value_norm,'%'))`)
console.log('模糊包含命中:', JSON.stringify(like[0]))
await pool.end()
