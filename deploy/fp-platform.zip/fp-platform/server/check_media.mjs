import mysql from 'mysql2/promise'
const pool = mysql.createPool({
  host: process.env.DB_HOST, port: 3306, database: process.env.DB_NAME,
  user: process.env.DB_USER, password: process.env.DB_PASSWORD,
  charset: 'utf8mb4', dateStrings: true
})
async function q(sql, p=[]) { const [r]=await pool.execute(sql,p); return r }
const tables = await q("SHOW TABLES LIKE 'real_data_tag_precision_samples'")
console.log('precision_samples exists:', tables.length>0)
const cnt = await q('SELECT COUNT(*) c FROM real_data_tag_precision_samples')
console.log('precision_samples rows:', cnt[0].c)
const mn = await q('SELECT COUNT(*) c FROM real_data_tag_precision_samples WHERE media_url IS NOT NULL AND media_url <> ""')
console.log('media_url non-empty:', mn[0].c)
const one = await q('SELECT sample_id, tag_id, media_url FROM real_data_tag_precision_samples WHERE media_url IS NOT NULL AND media_url <> "" LIMIT 3')
for (const r of one) console.log('SAMPLE', r.sample_id, r.tag_id, (r.media_url||'').slice(0,140))
await pool.end()
