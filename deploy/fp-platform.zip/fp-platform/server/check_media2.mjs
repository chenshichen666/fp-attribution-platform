import mysql from 'mysql2/promise'
const pool = mysql.createPool({
  host: process.env.DB_HOST, port: 3306, database: process.env.DB_NAME,
  user: process.env.DB_USER, password: process.env.DB_PASSWORD,
  charset: 'utf8mb4', dateStrings: true
})
async function q(sql, p=[]) { const [r]=await pool.execute(sql,p); return r }
const t1 = await q("SHOW TABLES LIKE 'real_data_samples'")
console.log('real_data_samples exists:', t1.length>0)
if(t1.length){
  const c = await q('SELECT COUNT(*) n FROM real_data_samples')
  console.log('real_data_samples rows:', c[0].n)
  const fp = await q('SELECT COUNT(*) n FROM real_data_samples WHERE is_fp=1')
  console.log('is_fp=1 rows:', fp[0].n)
  const mu = await q("SELECT COUNT(*) n FROM real_data_samples WHERE is_fp=1 AND media_url IS NOT NULL AND media_url<>''")
  console.log('is_fp=1 & media_url non-empty:', mu[0].n)
  const one = await q("SELECT sample_id, tag_id, media_url FROM real_data_samples WHERE is_fp=1 AND media_url IS NOT NULL AND media_url<>'' LIMIT 3")
  for(const r of one) console.log('SAMPLE', r.sample_id, r.tag_id, (r.media_url||'').slice(0,140))
}
await pool.end()
