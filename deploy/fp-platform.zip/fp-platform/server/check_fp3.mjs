import mysql from 'mysql2/promise'
const pool = mysql.createPool({ host:process.env.DB_HOST, port:3306, database:process.env.DB_NAME, user:process.env.DB_USER, password:process.env.DB_PASSWORD, charset:'utf8mb4', dateStrings:true })
const sHost = await pool.query(`SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(media_url,'//',-1),'/',1) h, COUNT(*) c FROM real_data_samples WHERE media_url<>'' GROUP BY h ORDER BY c DESC LIMIT 5`)
console.log('samples host:', JSON.stringify(sHost[0]))
const dHost = await pool.query(`SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(element_value_norm,'//',-1),'/',1) h, COUNT(*) c FROM ai_evaluate_detail_url_idx GROUP BY h ORDER BY c DESC LIMIT 5`)
console.log('ai_idx host:', JSON.stringify(dHost[0]))
// 看 ai_idx 是否被 samples media_url 前缀命中（前缀匹配）
const prefix = await pool.query(`SELECT COUNT(*) c FROM real_data_samples s WHERE EXISTS (SELECT 1 FROM ai_evaluate_detail_url_idx d WHERE s.media_url LIKE CONCAT(d.element_value_norm,'%') OR d.element_value_norm LIKE CONCAT(SUBSTRING_INDEX(s.media_url,'?',1),'%'))`)
console.log('前缀/包含命中:', JSON.stringify(prefix[0]))
await pool.end()
