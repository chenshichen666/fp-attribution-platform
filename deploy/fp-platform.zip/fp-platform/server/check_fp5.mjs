import mysql from 'mysql2/promise'
const pool = mysql.createPool({ host:process.env.DB_HOST, port:3306, database:process.env.DB_NAME, user:process.env.DB_USER, password:process.env.DB_PASSWORD, charset:'utf8mb4', dateStrings:true })
const like = await pool.query(`SELECT COUNT(*) c FROM real_data_samples s WHERE s.media_url<>'' AND EXISTS (SELECT 1 FROM ai_evaluate_detail_url_idx d WHERE s.media_url LIKE CONCAT('%',d.element_value_norm,'%'))`)
console.log('模糊包含命中:', JSON.stringify(like[0]))
await pool.end()
